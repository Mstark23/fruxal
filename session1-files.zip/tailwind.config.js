/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        navy: "#0F2B46",
        accent: "#E8483F",
        brand: { blue: "#1A73E8", green: "#1B9E5A", gold: "#D4A017" },
      },
    },
  },
  plugins: [],
};
