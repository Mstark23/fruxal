import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db/client";

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { name, industry } = await request.json();

    if (!name) {
      return NextResponse.json(
        { error: "Business name required" },
        { status: 400 }
      );
    }

    const userId = (session.user as any).id;

    // Create business and add user as owner
    const business = await prisma.business.create({
      data: {
        name,
        industry: industry || "OTHER",
        members: {
          create: {
            userId,
            role: "OWNER",
          },
        },
      },
    });

    return NextResponse.json(
      { message: "Business created", businessId: business.id },
      { status: 201 }
    );
  } catch (error: any) {
    console.error("Business creation error:", error);
    return NextResponse.json(
      { error: "Something went wrong" },
      { status: 500 }
    );
  }
}
