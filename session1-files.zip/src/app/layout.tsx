import "./globals.css";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Leak & Grow — Revenue Intelligence",
  description: "Find where your money leaks. Fix it. Grow.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-slate-50 text-gray-900 min-h-screen">
        {children}
      </body>
    </html>
  );
}
