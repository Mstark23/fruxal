"use client";

import Link from "next/link";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Nav */}
      <nav className="flex items-center justify-between px-8 py-4 bg-white border-b border-gray-200">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center text-white font-black text-sm">
            L
          </div>
          <span className="text-xl font-extrabold text-navy tracking-tight">
            Leak & Grow
          </span>
        </div>
        <div className="flex items-center gap-3">
          <Link
            href="/login"
            className="px-4 py-2 text-sm font-semibold text-gray-600 hover:text-gray-900 transition"
          >
            Sign In
          </Link>
          <Link
            href="/register"
            className="px-5 py-2 text-sm font-bold text-white bg-accent rounded-lg hover:bg-red-600 transition"
          >
            Get Started Free
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <main className="flex-1 flex items-center justify-center px-8">
        <div className="max-w-2xl text-center">
          <div className="inline-block px-4 py-1.5 bg-red-50 text-accent text-sm font-bold rounded-full mb-6">
            The average business leaks 1–9% of revenue without knowing it
          </div>
          <h1 className="text-5xl font-black text-navy leading-tight mb-6">
            Find Where Your
            <br />
            Money <span className="text-accent">Leaks</span>.
            <br />
            Fix It. Grow.
          </h1>
          <p className="text-lg text-gray-500 mb-8 max-w-lg mx-auto">
            Connect your accounting, banking, and contracts. Our AI finds the
            revenue you&apos;re losing — underpricing, unbilled work, missed
            collections, expired discounts — and shows you exactly how to fix it.
          </p>
          <div className="flex items-center justify-center gap-4">
            <Link
              href="/register"
              className="px-8 py-3 text-base font-bold text-white bg-navy rounded-xl hover:bg-blue-900 transition shadow-lg shadow-navy/20"
            >
              Start Your Free Leak Scan →
            </Link>
          </div>
          <p className="text-sm text-gray-400 mt-4">
            No credit card required · See results in 5 minutes
          </p>

          {/* Stats */}
          <div className="flex items-center justify-center gap-12 mt-16">
            <div className="text-center">
              <div className="text-3xl font-black text-navy">$47K</div>
              <div className="text-sm text-gray-400 font-medium">
                Avg. leaks found per business
              </div>
            </div>
            <div className="w-px h-12 bg-gray-200" />
            <div className="text-center">
              <div className="text-3xl font-black text-brand-green">59%</div>
              <div className="text-sm text-gray-400 font-medium">
                Recovery rate in first 90 days
              </div>
            </div>
            <div className="w-px h-12 bg-gray-200" />
            <div className="text-center">
              <div className="text-3xl font-black text-brand-blue">5 min</div>
              <div className="text-sm text-gray-400 font-medium">
                To first leak detected
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
