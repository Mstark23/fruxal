import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db/client";
import DashboardClient from "./DashboardClient";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    redirect("/login");
  }

  // Check if user has a business
  const membership = await prisma.businessMember.findFirst({
    where: { userId: (session.user as any).id },
    include: { business: true },
  });

  return (
    <DashboardClient
      userName={session.user.name || session.user.email || ""}
      userEmail={session.user.email || ""}
      business={membership?.business || null}
    />
  );
}
