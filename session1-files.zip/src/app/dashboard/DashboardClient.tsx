"use client";

import { signOut } from "next-auth/react";
import { useState } from "react";
import { useRouter } from "next/navigation";

interface Business {
  id: string;
  name: string;
  industry: string;
}

export default function DashboardClient({
  userName,
  userEmail,
  business,
}: {
  userName: string;
  userEmail: string;
  business: Business | null;
}) {
  const router = useRouter();
  const [showCreate, setShowCreate] = useState(!business);
  const [bizName, setBizName] = useState("");
  const [industry, setIndustry] = useState("FINANCIAL_ADVISORY");
  const [creating, setCreating] = useState(false);

  const industries = [
    { value: "FINANCIAL_ADVISORY", label: "Financial Advisory" },
    { value: "LAW_FIRM", label: "Law Firm" },
    { value: "ACCOUNTING", label: "Accounting Firm" },
    { value: "HEALTHCARE", label: "Healthcare" },
    { value: "CONSTRUCTION", label: "Construction" },
    { value: "RESTAURANT", label: "Restaurant" },
    { value: "CONSULTING", label: "Consulting" },
    { value: "INSURANCE_BROKERAGE", label: "Insurance Brokerage" },
    { value: "REAL_ESTATE", label: "Real Estate" },
    { value: "SAAS", label: "SaaS / Software" },
    { value: "ECOMMERCE", label: "E-Commerce" },
    { value: "OTHER", label: "Other" },
  ];

  const handleCreateBusiness = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bizName.trim()) return;
    setCreating(true);

    const res = await fetch("/api/business", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: bizName, industry }),
    });

    if (res.ok) {
      router.refresh();
      setShowCreate(false);
    }
    setCreating(false);
  };

  const initials = userName
    ? userName
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
        .slice(0, 2)
    : userEmail.slice(0, 2).toUpperCase();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Top Nav */}
      <div className="bg-gradient-to-r from-navy to-blue-800 px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center text-white font-black text-sm">
            L
          </div>
          <span className="text-lg font-extrabold text-white tracking-tight">
            Leak & Grow
          </span>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right hidden sm:block">
            <div className="text-sm font-semibold text-white">{userName || userEmail}</div>
            {business && (
              <div className="text-xs text-blue-200">{business.name}</div>
            )}
          </div>
          <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center text-sm font-bold text-white">
            {initials}
          </div>
          <button
            onClick={() => signOut({ callbackUrl: "/" })}
            className="text-xs text-blue-200 hover:text-white transition font-medium"
          >
            Sign Out
          </button>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-8">
        {/* No Business Yet — Onboarding */}
        {showCreate && !business ? (
          <div className="max-w-lg mx-auto">
            <div className="text-center mb-8">
              <div className="text-4xl mb-3">🎉</div>
              <h1 className="text-2xl font-extrabold text-gray-900 mb-2">
                Welcome to Leak & Grow
              </h1>
              <p className="text-gray-500">
                Let&apos;s set up your business to start finding revenue leaks.
              </p>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
              <form onSubmit={handleCreateBusiness} className="space-y-5">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                    Business Name
                  </label>
                  <input
                    type="text"
                    value={bizName}
                    onChange={(e) => setBizName(e.target.value)}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-navy"
                    placeholder="e.g. Gestion Patrimoine Bélanger"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                    Industry
                  </label>
                  <select
                    value={industry}
                    onChange={(e) => setIndustry(e.target.value)}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-navy bg-white"
                  >
                    {industries.map((ind) => (
                      <option key={ind.value} value={ind.value}>
                        {ind.label}
                      </option>
                    ))}
                  </select>
                </div>
                <button
                  type="submit"
                  disabled={creating}
                  className="w-full py-3 bg-navy text-white font-bold rounded-lg hover:bg-blue-900 transition disabled:opacity-50 text-sm"
                >
                  {creating ? "Creating..." : "Create Business →"}
                </button>
              </form>
            </div>
          </div>
        ) : (
          /* Dashboard — Business Exists */
          <>
            <div className="mb-8">
              <h1 className="text-2xl font-extrabold text-gray-900">
                {business?.name || "Dashboard"}
              </h1>
              <p className="text-gray-500 text-sm mt-1">
                {industries.find((i) => i.value === business?.industry)?.label || business?.industry}
              </p>
            </div>

            {/* Status Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <div className="bg-white rounded-xl border border-gray-200 p-6">
                <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">
                  🔍 Data Sources
                </div>
                <div className="text-3xl font-extrabold text-gray-900">0</div>
                <div className="text-sm text-gray-400 mt-1">No connections yet</div>
                <button className="mt-4 w-full py-2 text-sm font-bold text-brand-blue bg-blue-50 rounded-lg hover:bg-blue-100 transition">
                  + Connect QuickBooks
                </button>
              </div>

              <div className="bg-white rounded-xl border border-gray-200 p-6">
                <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">
                  🔴 Leaks Detected
                </div>
                <div className="text-3xl font-extrabold text-gray-300">—</div>
                <div className="text-sm text-gray-400 mt-1">
                  Connect data to start scanning
                </div>
              </div>

              <div className="bg-white rounded-xl border border-gray-200 p-6">
                <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">
                  💰 Revenue at Risk
                </div>
                <div className="text-3xl font-extrabold text-gray-300">—</div>
                <div className="text-sm text-gray-400 mt-1">
                  Waiting for first scan
                </div>
              </div>
            </div>

            {/* Next Steps */}
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <h2 className="text-lg font-extrabold text-gray-900 mb-4">
                Getting Started
              </h2>
              <div className="space-y-3">
                {[
                  {
                    step: 1,
                    title: "Connect QuickBooks",
                    desc: "Sync your invoices, clients, and payments automatically",
                    done: false,
                  },
                  {
                    step: 2,
                    title: "Connect your bank",
                    desc: "Link via Plaid for transaction and cash flow analysis",
                    done: false,
                  },
                  {
                    step: 3,
                    title: "Upload contracts",
                    desc: "Our AI reads fee schedules and finds billing gaps",
                    done: false,
                  },
                  {
                    step: 4,
                    title: "Review your first leaks",
                    desc: "See exactly where money is falling through the cracks",
                    done: false,
                  },
                ].map((item) => (
                  <div
                    key={item.step}
                    className="flex items-center gap-4 p-4 rounded-lg border border-gray-100 hover:border-gray-200 transition"
                  >
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                        item.done
                          ? "bg-green-100 text-green-600"
                          : "bg-gray-100 text-gray-400"
                      }`}
                    >
                      {item.done ? "✓" : item.step}
                    </div>
                    <div className="flex-1">
                      <div className="text-sm font-bold text-gray-900">
                        {item.title}
                      </div>
                      <div className="text-xs text-gray-400">{item.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
